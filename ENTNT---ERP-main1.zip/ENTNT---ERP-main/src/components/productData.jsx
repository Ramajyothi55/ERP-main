const initialProducts = [
    { id: 1, name: 'Product 1', category: 'Footwear', price: 90, stock: 100 },
    { id: 2, name: 'Product 2', category: 'Accessories', price: 300, stock: 50 },
    { id: 3, name: 'Product 3', category: 'Books', price: 200, stock: 75 },
    { id: 4, name: 'Product 4', category: 'Electronics', price: 90, stock: 150 },
    { id: 5, name: 'Product 5', category: 'Furniture', price: 100, stock: 10 },
    { id: 6, name: 'Product 6', category: 'Clothing', price: 500, stock: 15 },
  ];

export default initialProducts;