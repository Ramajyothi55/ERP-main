const initialOrders = [
    { id: 1, customerName: 'John Doe', orderDate: '2024-01-5', status: 'Pending' },
    { id: 2, customerName: 'Jane Smith', orderDate: '2024-02-2', status: 'Shipped' },
    { id: 3, customerName: 'Bob Johnson', orderDate: '2024-03-15', status: 'Delivered' },
    { id: 4, customerName: 'David', orderDate: '2024-03-10', status: 'Pending' },
    { id: 5, customerName: 'dawyn', orderDate: '2024-03-10', status: 'Shipped' },
    // ... add more orders as needed
  ];
  
  export default initialOrders;